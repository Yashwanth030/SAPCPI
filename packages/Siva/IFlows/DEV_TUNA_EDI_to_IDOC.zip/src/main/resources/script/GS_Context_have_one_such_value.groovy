import com.sap.it.api.mapping.*;


def void contextHasOneOfSuchValues(String[] contextValues, String[] suchValuesString, Output output, MappingContext context) {
  
  
  if (contextValues != null && contextValues.length > 0) {
   if (suchValuesString == null || suchValuesString.length == 0 || suchValuesString[0] == null) {
    throw new IllegalStateException("contextHasOneOfSuchValues: "
      + "there is no suchValuesString");
   }
   String[] suchValues = suchValuesString[0].split(";");
   String oneOfSuchValues = "false";
   fcontext: for (int i = 0; i < contextValues.length; i++) {
    for (int j = 0; j < suchValues.length; j++) {
     if (suchValues[j].equalsIgnoreCase(contextValues[i])) {
      oneOfSuchValues = "true";
      break fcontext;
     }
    }
   }
   output.addValue(oneOfSuchValues);
  } else {
   output.addValue("false");
  }
  
  
  }