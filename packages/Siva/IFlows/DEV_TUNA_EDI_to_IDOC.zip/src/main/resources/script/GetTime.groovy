import com.sap.it.api.mapping.*;

def String customFunc1(String P1,MappingContext context) {

         String value = context.getProperty(P1);
         
         String[] str;
         
            str = value.split(" ");
            
            def strs = str[3].replaceAll(":","")
     
    
         return strs;
}