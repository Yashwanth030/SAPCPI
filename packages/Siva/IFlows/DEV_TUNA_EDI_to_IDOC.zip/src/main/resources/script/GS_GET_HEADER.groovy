import com.sap.it.api.mapping.*;

def String getHeader(String header_name,MappingContext context)

{
  String headerValue= context.getHeader(header_name);
  return headerValue;
}