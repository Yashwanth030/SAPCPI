import com.sap.it.api.mapping.*;

def void existsAndHasValues(String[] values, Output output, MappingContext context) {
    if (values.length > 0) {
        values.each { s ->
          if (s != null && s.trim().length() > 0 && !output.isSuppress(s)) {
              output.addValue("true")
          } else {
              output.addValue("false")
          }
        }
    } else {
       output.addValue("false")
    }
}
