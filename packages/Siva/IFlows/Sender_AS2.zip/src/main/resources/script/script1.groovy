import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.commons.lang.StringEscapeUtils;
// import groovy.xml.MarkupBuilder
import java.util.HashMap;
def Message processData(Message message) {
       //Body 
        def body = message.getBody(java.lang.String) as String;
        
        if(body.length() > 300){
            body = body.substring(0,300);
        }
        message.setBody("<payload>" + StringEscapeUtils.escapeXml(body) + "</payload>");
        
        return message;
}