import org.osgi.framework.FrameworkUtil;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.op.b2b.monitor.api.*;
import com.sap.it.op.b2b.monitor.api.events.*;
import java.nio.charset.StandardCharsets;


def Message processData(Message message) {

    // Get headers
    def headers                    = message.getHeaders();
    def props                      = message.getProperties();
    def sndAdapterType             = headers.get("SAP_COM_SND_Adapter_Type");
    def sndAS2Filename             = headers.get("SAP_AS2Filename");
    def sndAS2MessageContentType   = headers.get("SAP_AS2MessageContentType");
    def sndAS2MessageID            = headers.get("SAP_AS2MessageID");
    def sndAS2MessageSubject       = headers.get("SAP_AS2MessageSubject");
    def sndAS2OwnID                = headers.get("SAP_AS2OwnID");
    def sndAS2PartnerEmail         = headers.get("SAP_AS2PartnerEmail");
    def sndAS2PartnerID            = headers.get("SAP_AS2PartnerID");
    def sndIDOCType                = headers.get("SapIDocType");
    def sndIDOCTransferID          = headers.get("SapIDocTransferId");
    def sndComSenderID             = "";
    def sndComReceiverID           = "";
    def sndComTransferID           = "";
    def sndComInterchangeType      = "";
    def sndDocumentStandard        = "";
    def sndPayloadFormat           = "";
    def partnerID                  = "";
    def sdnAuthenticatedUser       = headers.get("SapAuthenticatedUserName");
    def messageProcessingLogID     = headers.get("SAP_MessageProcessingLogID");
    def exceptionMessage           = props.get("CamelExceptionCaught");

    // AdapterType
    if (sndAdapterType == null) {
        // if as2 message id not null, then is as2
        if (sndAS2MessageID != null) {
            sndAdapterType = "AS2"; 
        } else {
            throw new IllegalStateException("Mandatory value sndAdapterType not provided.");
        }
    } else {
        sndAdapterType = sndAdapterType.trim();
    }

    //Message Content Type
    if (sndAS2MessageContentType == "application/EDIFACT"){
        sndDocumentStandard = "UN-EDIFACT";
		sndPayloadFormat    = "EDI_FLAT";			
    }
    else if (sndAS2MessageContentType == "application/EDI-X12"){
        sndDocumentStandard = "ASC-X12";
		sndPayloadFormat    = "EDI_FLAT";
    }
    else if (sndAdapterType == "IDOC"){
        sndDocumentStandard = "SAP_IDoc";
        sndPayloadFormat    = "XML";
    }
    else if (sndAdapterType == "SOAP"){
        sndDocumentStandard = "SAP_S4HANA_Cloud_SOA";
        sndPayloadFormat    = "XML";
    }
    else {
        
    }

    if (sndAS2OwnID != null){
        sndComReceiverID = sndAS2OwnID.trim();
    }
    else {
        sndComReceiverID = "";
    }

    if (sndAS2PartnerID != null){
        sndComSenderID = sndAS2PartnerID.trim();
    }
    else {
        sndComSenderID = "";
    }

    if (sndAS2MessageSubject != null){
        sndComInterchangeType = sndAS2MessageSubject.trim();
    }
    else if (sndIDOCType != null){
        sndComInterchangeType = "";
    }
    else {
        sndComInterchangeType = "";
    }

    if (sndAS2MessageID != null){
        sndComTransferID = sndAS2MessageID.trim();
    }
    else if (sndIDOCTransferID != null){
        sndComTransferID = sndIDOCTransferID.trim();
    }
    else {
        sndComTransferID = "";
    }

    //Get B2B classes and interfaces 
    def bundleContext = FrameworkUtil.getBundle(Class.forName("com.sap.gateway.ip.core.customdev.util.Message")).getBundleContext();
    def serviceRef = bundleContext.getServiceReference(Class.forName("com.sap.it.op.b2b.monitor.api.B2BMonitoringApi"));
    B2BMonitoringApi api = (B2BMonitoringApi) bundleContext.getService(serviceRef);

    //Create Orphaned Interchange and error event
    OrphanedInterchangeErrorEvent orphanedInterchangeErrorEvent = api.createOrphanedInterchangeErrorEvent();
    OrphanedInterchange orphanedInterchange = orphanedInterchangeErrorEvent.createOrphanedInterchange();
    orphanedInterchangeErrorEvent.setOrphanedInterchange(orphanedInterchange);
    
    //Fill data in OrphanedInterchange
    orphanedInterchange.setAdapterType(sndAdapterType);
    def body = message.getBody(java.lang.String) as String;
    orphanedInterchange.setPayload(body.getBytes(StandardCharsets.UTF_8));
    
    orphanedInterchange.addCommunicationProtocolHeader("SapAuthenticatedUserName", sdnAuthenticatedUser);
    orphanedInterchange.addCommunicationProtocolHeader("SAP_EDI_Document_Standard", sndDocumentStandard);
    orphanedInterchange.addCommunicationProtocolHeader("SAP_EDI_Payload_Format", sndPayloadFormat);
    if (sndAdapterType == "IDOC"){
        orphanedInterchange.addCommunicationProtocolHeader("SapIDocType", sndIDOCType);
        orphanedInterchange.addCommunicationProtocolHeader("SapIDocTransferId", sndIDOCTransferID);
    }
    if (sndAdapterType == "AS2"){
        orphanedInterchange.addCommunicationProtocolHeader("SAP_AS2Filename", sndAS2Filename);
        orphanedInterchange.addCommunicationProtocolHeader("SAP_AS2MessageContentType", sndAS2MessageContentType);    
        orphanedInterchange.addCommunicationProtocolHeader("SAP_AS2MessageID", sndAS2MessageID);
        orphanedInterchange.addCommunicationProtocolHeader("SAP_AS2MessageSubject", sndAS2MessageSubject);   
        orphanedInterchange.addCommunicationProtocolHeader("SAP_AS2OwnID", sndAS2OwnID);
        orphanedInterchange.addCommunicationProtocolHeader("SAP_AS2PartnerID", sndAS2PartnerID);
        orphanedInterchange.addCommunicationProtocolHeader("SAP_AS2PartnerEmail", sndAS2PartnerEmail);    
    }
        
    //Fill data for error event
    orphanedInterchangeErrorEvent.setErrorInformation(exceptionMessage.toString());
    orphanedInterchangeErrorEvent.setErrorCategory(ErrorCategory.CONFIGURATION_ACCESS);
    orphanedInterchangeErrorEvent.setMonitoringReference(messageProcessingLogID);
    orphanedInterchangeErrorEvent.setMonitoringReferenceType(MonitoringReferenceType.MPL);

    orphanedInterchangeErrorEvent.submit();
    
    return message;
}