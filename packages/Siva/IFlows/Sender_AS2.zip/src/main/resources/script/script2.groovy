import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.osgi.framework.FrameworkUtil;
import com.sap.it.op.b2b.monitor.api.*;
import com.sap.it.op.b2b.monitor.api.events.*;
import java.nio.charset.StandardCharsets;


def Message processData(Message message) {
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);    
    if(service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    
    def headers                    = message.getHeaders();
    def sndAdapterType             = headers.get("SAP_COM_SND_Adapter_Type");
    def sndAS2Filename             = headers.get("SAP_AS2Filename");
    def sndAS2MessageContentType   = headers.get("SAP_AS2MessageContentType");
    def sndAS2MessageID            = headers.get("SAP_AS2MessageID");
    def sndAS2ContentType          = headers.get("SAP_COM_SND_Content_Type");
    //def sndAS2MessageSubject       = headers.get("SAP_AS2MessageSubject");
    def sndAS2MessageSubject;
    //def sndAS2OwnID                = headers.get("SAP_AS2OwnID");
    def sndAS2OwnID;
    def sndAS2PartnerEmail         = headers.get("SAP_AS2PartnerEmail");
    //def sndAS2PartnerID            = headers.get("SAP_AS2PartnerID");
    def sndAS2PartnerID;
    //def sndIDOCType                = headers.get("SapIDocType");
    def sndIDOCType                = "";
    def sndIDOCTransferID          = headers.get("SapIDocTransferId");
    def sndSOAPIfMessageHeader     = headers.get("SAP_COM_SND_If_Message_Header");
    def sndComSenderID             = "";
    def sndComReceiverID           = "";
    def sndComTransferID           = "";
    def sndComInterchangeType      = "";
    def sndDocumentStandard        = "";
    def sndPayloadFormat           = "";
    def partnerID                  = "";

    //Adapter Type
    if (sndAdapterType == null){
        throw new IllegalStateException("Mandatory value sndAdapterType not provided.");
    }
    else{
        sndAdapterType = sndAdapterType.trim();
    }

    //Message Content Type
    if (sndAdapterType == "AS2") {
        if (sndAS2MessageSubject != null){
            sndComInterchangeType = "";        
        }
    }
    if (sndAS2ContentType == "UNA" || sndAS2ContentType == "UNB") {
        sndAS2MessageContentType = "application/EDIFACT"
        message.setHeader("SAP_AS2MessageContentType", sndAS2MessageContentType);
        sndDocumentStandard = "UN-EDIFACT";
		sndPayloadFormat    = "EDI_FLAT";			
    }
    else if (sndAS2ContentType == "ISA") {
        sndAS2MessageContentType = "application/EDI-X12"
        message.setHeader("SAP_AS2MessageContentType", sndAS2MessageContentType);
        sndDocumentStandard = "ASC-X12";
		sndPayloadFormat    = "EDI_FLAT";
    }
    else if (sndAdapterType == "IDOC"){
        sndDocumentStandard = "SAP_IDoc";
        sndPayloadFormat    = "XML";
        if (sndIDOCType != null){
            sndComInterchangeType = "";        
        }
    }
    else if (sndAdapterType == "SOAP"){
        sndDocumentStandard = "SAP_S4HANA_Cloud_SOA";
        sndPayloadFormat    = "XML";
        if (sndSOAPIfMessageHeader == "false") {
            sndComInterchangeType = "RecInBody";
        }
    }
    else {
        throw new IllegalStateException("Mandatory value sndDocumentStandard can't be set.");
    }

    if (sndAS2OwnID != null){
        sndComReceiverID = sndAS2OwnID.trim();
    }
    else {
        sndComReceiverID = "";
    }

    if (sndAS2PartnerID != null){
        sndComSenderID = sndAS2PartnerID.trim();
    }
    else {
        sndComSenderID = "";
    }

    if (sndAS2MessageID != null){
        sndComTransferID = sndAS2MessageID.trim();
    }
    else if (sndIDOCTransferID != null){
        sndComTransferID = sndIDOCTransferID.trim();
    }
    else {
        sndComTransferID = "";
    }


	def matchString          = sndAdapterType + "-" + sndDocumentStandard + "-" + sndComSenderID + "-" + sndComReceiverID + "-" + sndComInterchangeType;
    def matchStringLowerCase = matchString.toLowerCase();
 
 	// Great hash from the match string
    try {
        MessageDigest digest = MessageDigest.getInstance("MD5");
        digest.update(matchStringLowerCase.bytes);
        partnerID = "SAP_TPM_" + new BigInteger(1, digest.digest()).toString(16).padLeft(32, '0');
        message.setProperty("SAP_Com_Partner_ID_String", matchString);
        message.setProperty("SAP_Com_Partner_ID_Hash", partnerID);
    } 
    catch (NoSuchAlgorithmException e) {
        log.error('Error creating MD5 hash', e);
        throw new IllegalStateException("PartnerID hash can't be generated.");
    } 
    
    message.setHeader("ACTUAL_PARTNER_ID", partnerID);
    // Set binary parameters
    if (sndSOAPIfMessageHeader == "false") {
        message.setHeader("EXTRACT_XSLT", "pd:" + partnerID + ":EXTRACT_BODY_XSLT:Binary");
    } else {
        message.setHeader("EXTRACT_XSLT", "pd:" + partnerID + ":EXTRACT_XSLT:Binary");
    }

    // get communication parameters for receiver
    def tpaSndComSenderName   = service.getParameter("SAP_COM_SND_Sender_Name", partnerID , String.class);
    def tpaSndComReceiverName = service.getParameter("SAP_COM_SND_Receiver_Name", partnerID , String.class);
    def tpaSndTimeZone        = service.getParameter("SAP_TPA_SND_TimeZone", partnerID , String.class);
    def sndMsgVersion         = service.getParameter("SAP_EDI_Message_Version", partnerID , String.class);
      
    // set general trading partner agreement properties for monitoring. 
    message.setHeader("SAP_EDI_Document_Standard", sndDocumentStandard);
    message.setHeader("SAP_EDI_Payload_Format", sndPayloadFormat);
    message.setHeader("SAP_EDI_Message_Version", sndMsgVersion);
    message.setHeader("SAP_SND_Communication_Transfer_ID", sndComTransferID);
    message.setHeader("SAP_TPA_SND_Communication_Sender_Name", tpaSndComSenderName);
    message.setHeader("SAP_TPA_SND_Communication_Receiver_Name", tpaSndComReceiverName);
    message.setProperty("SAP_TPA_SND_TimeZone", tpaSndTimeZone);
    
    return message;
}