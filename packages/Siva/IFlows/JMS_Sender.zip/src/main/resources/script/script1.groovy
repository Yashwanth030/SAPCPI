import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;def Message processData(Message message) {
// Get Headers
def map;
map = message.getHeaders();
def retry;
retry = map.get("RetryCount");
if (retry == null) {
retry = 1;
}
else {
retry = retry + 1;
}
message.setHeader("RetryCount", retry);
return message;}