import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import groovy.xml.*;

def String deriveDateTime(String arg1){
    
    Date inputDate_parsed=new SimpleDateFormat("yyyy/MM/dd").parse(arg1);  

    DateFormat dateFormat_required = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

    def converted_datetime=dateFormat_required.format(inputDate_parsed);
    
    return converted_datetime;
}


def String replaceString(String arg1, String replaceChar, String replaceByChar){
    
    arg1 = (arg1) ? arg1.replaceAll(replaceChar,replaceByChar) : arg1;
    
    return arg1;
}