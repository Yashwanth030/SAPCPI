import com.sap.it.api.mapping.*;

def void concatenateContext(String[] is, Output output, MappingContext context) {
       /* String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);*/
        
        String target="";

        for(int i = 0;i<is.length;i++)

        {

            target = target+is[i];

                if (i != is.length-1)

                    {

// if i not equal to personNum.length -1

                        target = target+"," ;

                    }

                       

        }
         output.addValue(target);
}