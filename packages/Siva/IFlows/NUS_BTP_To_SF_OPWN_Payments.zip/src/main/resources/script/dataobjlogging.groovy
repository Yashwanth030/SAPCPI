import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
def Message processOTPResponse(Message message) {
    
    def prop = message.getProperties()
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // save attachment upsert response
     String body = message.getBody(java.lang.String) as String;
     message.setProperty("OTPUpsertResponse", body);

    // String FinalBody = prop.get("finalBody")
    // if(FinalBody)
    // message.setBody(FinalBody);
    
      return message;
}