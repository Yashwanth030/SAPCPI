<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="xs">
    <xsl:output omit-xml-declaration="yes" indent="yes"/>
	<xsl:template match="node()|@*">
		<xsl:copy>
			<xsl:apply-templates select="node()|@*"/>
		</xsl:copy>
	</xsl:template>
	<xsl:template match="OpwnPaymentImage">
		<root>
			<xsl:for-each-group select="OpwnPaymentImageType" group-by="STAFF_ID">
				<staffList>
					<staffId>
						<xsl:value-of select="STAFF_ID"/>
					</staffId>
					<EmpPayCompNonRecurring>
						<xsl:for-each select="current-group()">
							<EmpPayCompNonRecurring>
								<userId>
									<xsl:value-of select="STAFF_ID"/>
								</userId>
								<payDate>
									<xsl:value-of select="MODIFIED_ON"/>
								</payDate>
								<customString10>
									<xsl:value-of select="WBS"/>
								</customString10>
								<customString11>
									<xsl:value-of select="REQ_REFERENCE_ID"/>
								</customString11>
								<value>
									<xsl:value-of select="AMOUNT"/>
								</value>
								<currencyCode>
									<xsl:value-of select="CURRENCY"/>
								</currencyCode>
								<payComponentCode>
									<xsl:value-of select="PAYMENT_TYPE_C"/>
								</payComponentCode>
							</EmpPayCompNonRecurring>
						</xsl:for-each>
					</EmpPayCompNonRecurring>
				</staffList>
			</xsl:for-each-group>
		</root>
	</xsl:template>
</xsl:stylesheet>