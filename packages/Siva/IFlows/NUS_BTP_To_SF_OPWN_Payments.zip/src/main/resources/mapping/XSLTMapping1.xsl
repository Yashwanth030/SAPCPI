<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="xs">
	<xsl:output omit-xml-declaration="yes" indent="yes"/>
	<xsl:template match="node()|@*">
		<xsl:copy>
			<xsl:apply-templates select="node()|@*"/>
		</xsl:copy>
	</xsl:template>
	<xsl:template match="EmpPayCompNonRecurring">
		<EmpPayCompNonRecurring>
			<xsl:for-each-group select="EmpPayCompNonRecurring" group-by="concat(userId, '+', customString10, '+', payComponentCode)">
				<EmpPayCompNonRecurring>
					<xsl:copy-of select="current-group()[1]/*[starts-with(name(),'key')]"/>
                                          				
                    <userId>
						<xsl:value-of select="userId"/>
					</userId>
					<payDate>
						<xsl:value-of select="payDate"/>
					</payDate>
					<customString10>
						<xsl:value-of select="customString10"/>
					</customString10>
					<customString11>
						<xsl:value-of select="customString11"/>
					</customString11>
					<value>
						<xsl:value-of select="sum(current-group()/value)"/>
					</value>
					<currencyCode>
						<xsl:value-of select="currencyCode"/>
					</currencyCode>
					<payComponentCode>
						<xsl:value-of select="payComponentCode"/>
					</payComponentCode>
				</EmpPayCompNonRecurring>
			</xsl:for-each-group>
		</EmpPayCompNonRecurring>
	</xsl:template>
</xsl:stylesheet>