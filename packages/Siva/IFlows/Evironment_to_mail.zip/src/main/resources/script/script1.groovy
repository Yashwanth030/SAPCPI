import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import groovy.xml.*;

def Message processData(Message message) {

    def baseUrl = "${message.getHeaders().get('CamelHttpUrl')}".toString()
    def Environment="";
    if(baseUrl.contains("inccpiprod"))
    {
        Environment="PROD"
    }
    else if(baseUrl.contains("inccpitest"))
    {
        Environment="TEST"
    }
    else {
        Environment="DEV"
    }

     //Set mail recipients
       def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
       def value = valueMapApi.getMappedValue('KEY', 'ENV', Environment, 'VALUE', 'DIST_LIST');
       message.setHeader("Mail", value)
       message.setHeader("ENV", Environment)
    return message;
}