import com.sap.it.api.mapping.*;
import groovy.json.JsonSlurper;
import com.sap.it.api.mapping.MappingContext;

def String getProperty(String property_name,String Staffid, MappingContext context) {

    def propValue= context.getProperty(property_name);
    return propValue;

}