import com.sap.it.api.mapping.*;
import java.lang.*;
import java.util.*;

def void cartesianProduct(String[] amt,String[] val,String[] flag, Output output, MappingContext context) {
    if(flag[0].equals("true"))
    {
        float temp = 0.0;
        float amount = 0.0;
        float value1 = 0.0;
        
            if(amt.length > 1)
            {
                for(int ac = 0; ac < amt.length;ac++)
                {
                    for(int c = 0; c < val.length;c++)
                    {
                        amount = Float.parseFloat(amt[ac]);
                        value1 = Float.parseFloat(val[c]);
                        temp = value1/100 *amount;
                        output.addValue(temp.toString());
                        temp = 0.0;
                    }
                }
                
            }
            if(amt.length <= 1)
            {
                for(int c = 0; c < val.length; c++)
                {
                    amount = Float.parseFloat(amt[0]);
                    value1 = Float.parseFloat(val[c]);
                    temp = value1/100 *amount;
                    output.addValue(temp.toString());
                    temp = 0.0;
                }
            }
    } 
    if(flag[0].equals("false"))
    {
        String temp = "";
        
            if(amt.length > 1)
            {
                for(int ac = 0; ac < amt.length;ac++)
                {
                    for(int c = 0; c < val.length;c++)
                    {
                        temp = val[c];
                        output.addValue(temp);
                        temp = "";
                    }
                }
                
            }
            if(amt.length <= 1)
            {
                for(int c = 0; c < val.length; c++)
                {
                    temp = val[c];
                    output.addValue(temp);
                    temp = "";
                }
            }
    }
    if(flag[0].contains("PT"))
    {
        String temp = "";
        int ctr = 0;
        
            if(amt.length > 1)
            {
                for(int ac = 0; ac < amt.length;ac++)
                {
                    for(int c = 0; c < val.length;c++)
                    {
                        ctr = ctr + 1;
                        temp = flag[0] + ctr ;
                        output.addValue(temp);
                        temp = "";
                    }
                }
                
            }
            if(amt.length <= 1)
            {
                for(int c = 0; c < val.length; c++)
                {
                    ctr = ctr + 1;
                    temp = flag[0] + ctr ;
                    output.addValue(temp);
                    temp = "";
                }
            }
    }
    if(flag[0].equals("ptype"))
    {
        String temp = "";
        int ctr = 0;
        
            if(amt.length > 1)
            {
                for(int ac = 0; ac < val.length;ac++)
                {
                    for(int c = 0; c < amt.length ;c++)
                    {
                        temp = val[ac] 
                        output.addValue(temp);
                        temp = "";
                    }
                }
                
            }
            if(amt.length <= 1)
            {
                for(int c = 0; c < val.length; c++)
                {
                    temp = val[c] 
                    output.addValue(temp);
                    temp = "";
                }
            }
    }
        
}
