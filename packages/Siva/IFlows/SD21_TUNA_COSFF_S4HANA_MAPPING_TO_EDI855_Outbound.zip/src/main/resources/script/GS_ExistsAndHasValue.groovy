import com.sap.it.api.mapping.*;
def void existandhasvalues(String[] value, Output output, MappingContext context) {
if (value.length > 0) {
value.each { s ->
if (s != null && s.trim().length() > 0 && !output.isSuppress(s)) {
output.addValue("true")
} else {
output.addValue("false")
}
}
} else {
output.addValue("false")
    
}
}

