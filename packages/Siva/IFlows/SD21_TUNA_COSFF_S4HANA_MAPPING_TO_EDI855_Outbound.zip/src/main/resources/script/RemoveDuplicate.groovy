import com.sap.it.api.mapping.*;

def void ISduplicate(String[] is, Output output, MappingContext context) {
   for(i=0;i<is.length;i++)
   {
      for(j=i+1;j=is.length;j++)
      {
       
       if(is[i]==is[j]) 
    { 
	  String str[i]= is[i];
	output.addValue(str[i]); 
     }
    }
       
   }
output.addValue(false);
}