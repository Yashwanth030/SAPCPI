import com.sap.it.api.mapping.*;

def void RemoveDuplicates(String Equal_Cond,String IDTNR_Counter,String IDTNRExtrnl_Countr, String IDTNR,Output output)
{

   if (Equal_Cond)
   {
      output.addValue(IDTNR);
   }


       
}