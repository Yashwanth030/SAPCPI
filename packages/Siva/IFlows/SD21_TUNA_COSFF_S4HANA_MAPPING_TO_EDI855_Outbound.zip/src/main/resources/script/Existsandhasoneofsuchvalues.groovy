import com.sap.it.api.mapping.*;
def void existsAndHasOneOfSuchValues(String[] contextValues, String []suchValuesString,  Output output, MappingContext context) {
  if (suchValuesString == null || suchValuesString.length == 0) {
   throw new IllegalStateException(
     "createIfHasOneOfSuchValues: there is no suchValuesString");
  }
  if ( contextValues.length > 0) {
   String[] suchValues = suchValuesString[0].split(";");
   for (int i = 0; i < contextValues.length; i++) {
   String value = output.isSuppress(contextValues[i]);
   //  String value = output.addSuppress(contextValues[i].add);
    for (int j = 0; j < suchValues.length; j++) {
     if (suchValues[j].equalsIgnoreCase(contextValues[i])) {
      value = "true";
      break;
     }
    }
    output.addValue(value);
   }
  }
   
}
