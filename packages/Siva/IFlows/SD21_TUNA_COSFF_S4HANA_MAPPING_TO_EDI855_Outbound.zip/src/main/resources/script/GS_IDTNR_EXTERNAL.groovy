import com.sap.it.api.mapping.*;

def void DuplicateHandling(String[] Counter_Cond,String[] IDTNR_Counter,String[] IDTNRExtrnl_Countr,String[] IDTNR,String[] IDTNRWDp,Output output, MappingContext context) {


if (IDTNR_Counter == IDTNRExtrnl_Countr )
{
   
   for(int i=0;i<IDTNRWDp.length;i++)
    {
       output.addValue(IDTNRWDp[i]) ;
        
      //  output.addValue("true") ;
    }

    
}
else 
{
    for(int i=0;i<IDTNR.length;i++)
    {
      output.addValue(IDTNR[i]) ;
      //  output.addValue("false") ;
        
    } 
}
  
}
 
